import UIKit

// Our defined enum
// bisa untuk kategori
// bisa camel case tapi lebih enak dibaca dengan huruf besar diawal

enum ArahMataAngin {
    case utara
    case selatan
    case barat
    case timur
}
var myDirection: ArahMataAngin = .barat

if myDirection == .barat{
print("I'm going to west")
}

//kalau switch harus semua case dari enum diatas, kalau if gak perlu
switch myDirection {
case .barat:
    print("Going to west")
case .timur:
    print("Going to east")
case .utara:
    print("Going to north")
case .selatan:
    print("Going to south")
}

//Challenge

enum JenisSampah {
    case foodWaste
    case plastic
    case paper
    case metal
    case glass
    case rubber
}

var tempatSampah: JenisSampah = .foodWaste
switch tempatSampah {
case .foodWaste:
    print("put in the Red Bin")
case .plastic:
    print("put in the Blue Bin")
case .paper:
    print("put in the White Bin")
case .metal:
    print("put in the Grey Bin")
case .glass:
    print("put in the Cyan Bin")
case .rubber:
    print("put in the Black Bin")
}
